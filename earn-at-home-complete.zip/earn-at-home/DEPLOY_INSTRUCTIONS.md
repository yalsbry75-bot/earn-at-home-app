# Earn at Home — Production Deployment Guide

## Project Structure

```
earn-at-home/
├── client/                  ← React source (Vite + Tailwind v4 + React 19)
│   ├── index.html           ← Vite entry point
│   ├── public/              ← Static assets (icon, manifest)
│   └── src/                 ← Full source: pages, components, services, hooks
├── functions/               ← Firebase Functions (Node.js 20)
│   ├── src/index.ts         ← Functions source
│   ├── lib/index.js         ← Compiled output (ready to deploy)
│   └── package.json
├── server/                  ← Express server (local dev only)
│   └── index.ts
├── shared/                  ← Shared code between client and server
│   └── const.ts
├── dist/                    ← Production build output
│   ├── index.js             ← Built server entry
│   └── public/              ← Firebase Hosting serves this folder
│       ├── index.html       ← SPA entry (clean, 1.4KB)
│       ├── manifest.json    ← PWA manifest
│       ├── app-icon.png     ← App icon
│       └── assets/          ← Hashed JS + CSS bundles
├── firebase.json            ← Hosting + Functions config
├── .firebaserc              ← !! Update with your project ID
├── .env.production.example  ← !! Fill in your Firebase credentials
├── package.json             ← Root workspace (pnpm)
└── vite.config.ts           ← Vite config (clean, no Manus plugins)
```

---

## Step 1 — Prerequisites

```bash
npm install -g firebase-tools
npm install -g pnpm
firebase login
```

---

## Step 2 — Update .firebaserc

Edit `.firebaserc` — replace `YOUR_FIREBASE_PROJECT_ID` with your actual Firebase project ID:

```json
{
  "projects": {
    "default": "my-actual-project-id"
  }
}
```

---

## Step 3 — Set Firebase Environment Variables

1. Copy `.env.production.example` → `.env.production`
2. Fill in all `VITE_FIREBASE_*` values from your Firebase Console:
   - Go to Firebase Console → Project Settings → Your apps → Web app → Config

> **Important:** These env vars are baked into the client bundle at build time.
> The `dist/` folder in this package already contains a built app with placeholder values.
> To use your real Firebase project, you must rebuild (see Step 5).

---

## Step 4 — Deploy Immediately (with placeholder Firebase config)

If you want to deploy the pre-built app right now:

```bash
firebase deploy --only hosting
```

The app will load correctly but Firebase auth/database calls will fail until
you rebuild with real credentials.

---

## Step 5 — Full Production Rebuild + Deploy

After filling in `.env.production`:

```bash
# Install root dependencies
pnpm install

# Build client + server
pnpm run build

# Install and compile Firebase Functions
cd functions && pnpm install && pnpm run build && cd ..

# Deploy hosting + functions
firebase deploy
```

---

## Verify Deployment

After deploying, visit:
- `https://YOUR_PROJECT_ID.web.app`
- `https://YOUR_PROJECT_ID.firebaseapp.com`

You should see the Arabic splash screen → landing page.

---

## Local Development

```bash
pnpm install
pnpm run dev        # Starts Vite dev server at http://localhost:3000
```

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19, Vite 7, Tailwind CSS v4 |
| Routing | Wouter v3 |
| State | Zustand v5 |
| UI | shadcn/ui (Radix + CVA) |
| Animation | Framer Motion v12 |
| Backend | Firebase Firestore + Auth |
| Functions | Firebase Functions v6 (Node 20) |
| i18n | i18next (Arabic RTL primary) |
| Forms | React Hook Form + Zod |

---

## Troubleshooting

**"Page Not Found" on Firebase Hosting**
→ Check that `firebase.json` has `"rewrites": [{"source": "**", "destination": "/index.html"}]` — already configured.

**Firebase auth/data not working**
→ You need to rebuild with real credentials in `.env.production`. Run Step 5.

**Functions deploy error**
→ Ensure Firebase project is on Blaze (pay-as-you-go) plan — required for Functions.

**Blank page / app doesn't load**
→ Check browser console for Firebase config errors. Make sure your Firebase project
has Authentication and Firestore enabled.
