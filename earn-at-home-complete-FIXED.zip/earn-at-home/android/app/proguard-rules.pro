# Capacitor / Cordova bridge classes must not be obfuscated
-keep public class com.getcapacitor.** { *; }
-keep public class * extends com.getcapacitor.Plugin
-keep public class * extends com.getcapacitor.PluginCall
-keepclassmembers class * {
    @com.getcapacitor.annotation.CapacitorPlugin *;
    @com.getcapacitor.PluginMethod *;
}

# WebView JS interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Firebase (if a future native Firebase SDK is added)
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
