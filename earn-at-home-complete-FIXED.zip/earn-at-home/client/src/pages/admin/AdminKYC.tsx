import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { withdrawalService } from '../../services/withdrawalService';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { firestore } from '../../firebase/config';
import { Button } from '../../components/ui/button';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table';
import { toast } from 'sonner';
import { Check, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { AdminLayout } from '../../components/admin/AdminLayout';

interface KycRecord {
  id: string; // document id == userId
  userId: string;
  level: number;
  status: string;
  fullName?: string;
  country?: string;
  idType?: string;
  idNumber?: string;
  submittedAt?: Date;
}

export default function AdminKYC() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [records, setRecords] = useState<KycRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user || user.role !== 'admin') return;

    const q = query(collection(firestore, 'kyc'), orderBy('submittedAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        submittedAt: doc.data().submittedAt?.toDate?.(),
      } as KycRecord));
      setRecords(docs);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleDecision = async (userId: string, decision: 'verified' | 'rejected') => {
    try {
      await withdrawalService.verifyKyc(userId, decision);
      toast.success(decision === 'verified' ? t('admin.kyc.approveSuccess') || 'KYC approved' : t('admin.kyc.rejectSuccess') || 'KYC rejected');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pending</Badge>;
      case 'verified':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Verified</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (user?.role !== 'admin') return <div className="p-8 text-center text-red-500">Access Denied</div>;

  return (
    <AdminLayout title={t('admin.kyc.title') || 'KYC Review'}>
      <div className="p-4 md:p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">{t('admin.kyc.title') || 'KYC Review'}</h1>
          <p className="text-muted-foreground">
            {t('admin.kyc.subtitle') || 'Review and approve identity verification submissions'}
          </p>
        </div>

        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User ID</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>Full Name</TableHead>
                <TableHead>Country</TableHead>
                <TableHead>ID Type / Number</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">Loading...</TableCell>
                </TableRow>
              )}
              {!isLoading && records.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    No KYC submissions yet
                  </TableCell>
                </TableRow>
              )}
              {records.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-mono text-xs">{record.userId}</TableCell>
                  <TableCell>{record.level}</TableCell>
                  <TableCell>{record.fullName || '-'}</TableCell>
                  <TableCell>{record.country || '-'}</TableCell>
                  <TableCell>{record.idType ? `${record.idType} / ${record.idNumber}` : '-'}</TableCell>
                  <TableCell>{getStatusBadge(record.status)}</TableCell>
                  <TableCell className="text-right space-x-2">
                    {record.status === 'pending' && (
                      <>
                        <Button size="sm" variant="outline" className="text-green-600" onClick={() => handleDecision(record.userId, 'verified')}>
                          <Check className="w-4 h-4 mr-1" /> Approve
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600" onClick={() => handleDecision(record.userId, 'rejected')}>
                          <X className="w-4 h-4 mr-1" /> Reject
                        </Button>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    </AdminLayout>
  );
}
